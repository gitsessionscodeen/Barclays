import pyodbc
from fpdf import FPDF

def pdf_file():
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font(family="Arial", size=15)
    f = open("emp_data.txt", "r")
    for x in f:
        pdf.cell(200, 10, txt=x, ln=1, align='C')
    # save the pdf with name .pdf
    pdf.output("database.pdf")

pdf_file()
