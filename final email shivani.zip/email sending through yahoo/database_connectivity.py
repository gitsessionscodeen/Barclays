import pyodbc
def read():
    conn = pyodbc.connect(
        "Driver={SQL Server Native Client 11.0};"
        "Server=SHIVANI;"
        "Database=python_sql;"
        "Trusted_Connection=yes;"
    )
    print("Connection established successfully from database")
    cursor = conn.cursor()
    cursor.execute("select * from workers")
    for row in cursor:
        with open('emp_data.txt','a+') as fp:
            data = fp.write(str(row))
            data =fp.write('\n')
        print(f'row = {row}')
    print()


read()