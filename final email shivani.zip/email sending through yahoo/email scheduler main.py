'''

https://docs.python.org/3/library/email.examples.html
https://www.geeksforgeeks.org/how-to-send-automated-email-messages-in-python/
'''

import schedule
import time
import smtplib
import appuser as ap
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
import logging
import os
from database_connectivity import read
import text_to_pdf as tpdf

filename1 = os.path.basename(__file__)
logging.basicConfig(filename='test.log', filemode='w', level=10,
                    format='%(asctime)s:%(name)s:%(levelname)s:%(message)s',
                    datefmt='%d/%m/%Y %H:%M:%S')

logger = logging.getLogger(filename1)


def email_send():
    receiver_address = {'Ajay': 'ajaypatel5104@gmail.com',
                        'Shivani': 'shivani8225929443@gmail.com',
                        #'Kantilal': 'chandrasekhar.nayak@hyrrokkinresearch.in.net',
                        'Chetan': 'chetanchitte7@gmail.com',
                        'Roshni': 'roshni.sundge@gmail.com'
                        }
    for name, email in receiver_address.items():
        logger.info('receiver email received')
        mail_content = ('Dear {}'.format(name))
        logger.info("mail content read")
        # The mail addresses and password
        sender_address = ap.sender_email
        logger.info('sender email received')
        sender_pass = ap.password
        logger.info('sender password received')

        # Setup the MIME
        message = MIMEMultipart()
        message['From'] = sender_address
        message['To'] = email
        message['Subject'] = 'A test mail sent by Python. It has an attachment.'

        # The subject line
        # The body and the attachments for the mail
        message.attach(MIMEText(mail_content, 'plain'))
        logger.info('draft mail')
        try:
            file_list = ['test.log', 'database.pdf']
            for file in file_list:
                attach_file_name = file
                attach_file = open(attach_file_name, 'rb')  # Open the file as binary mode used b for pdf file
                payload = MIMEBase('application', 'octate-stream')
                payload.set_payload((attach_file).read())

                encoders.encode_base64(payload)  # encode the attachment
                # add payload header with filename
                logger.info('add payload header with filename')
                payload.add_header('Content-Decomposition', 'attachment', filename=attach_file_name)
                message.attach(payload)
                logger.info(f'{attach_file_name} successfully attatched')

        except FileNotFoundError as msg:
            print(f"Error in file {msg}")
            logger.error('file not found')
        # Create SMTP session for sending the mail
        try:
            session = smtplib.SMTP('smtp.gmail.com', 587)  # use gmail with port
            session.starttls()  # enable security
            session.login(sender_address, sender_pass)  # login with mail_id and password
            text = message.as_string()
            session.sendmail(sender_address, email, text)
            session.quit()

            logger.info("session quit successfully")
        except Exception as msg:
            print('SMTP connection error', msg)
            logger.critical('SMTP connection error')


def main():
    read()
    tpdf.pdf_file()
    email_send()
    # schedule.every(1).minutes.do(email_send)
    # schedule.every().friday.do(email_send)
    # while True:
    #     schedule.run_pending()
    #     time.sleep(1)

    print('Mail Sent')
    logger.info("mail sent")


if __name__ == "__main__":
    main()
