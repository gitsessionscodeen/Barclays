'''

this is a simple email sending code without any attatchments
'''

import smtplib
import appuser
import database_connectivity as dc
with smtplib.SMTP('smtp.gmail.com') as connection:    #smtp.gmail.com
    connection.starttls()

    connection.login(user=appuser.sender_email, password=appuser.password)

    receiver_email = ['ajaypatel5104@gmail.com']

    for email in receiver_email:
        connection.sendmail(from_addr=appuser.sender_email,
                        to_addrs=email,
                        msg='subject:Reg. Google Meet\n\n I have sent this mail by python..please connect at 9 pm for linux, thanks')
# connection.close()
print('mail sent')
